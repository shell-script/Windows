// ==UserScript==
// @name         Bilibili 翻页评论区
// @namespace    MotooriKashin
// @version      0.2.0
// @description  恢复原来的翻页评论区，同时修复评论楼层号。
// @author       MotooriKashin
// @match        *://*.bilibili.com/*
// @resource     script https://cdn.jsdelivr.net/gh/MotooriKashin/Bilibili-Old/JavaScript/comment.min.js
// @run-at       document-start
// @grant        GM_getResourceText
// @license      MIT License
// ==/UserScript==

(function() {
    'use strict';

    function addCss(css, id) {
        if (!css) return;
        if (!document.head) return setTimeout(() => { this.addCss(css, id) });
        let style = document.createElement("style");
        if (id) {
            if (document.querySelector("#" + id)) return;
            style.setAttribute("id", id);
        }
        style.setAttribute("type", "text/css");
        style.appendChild(document.createTextNode(css));
        if (document.head) {
            document.head.appendChild(style);
            let link = document.createElement("link");
            link.setAttribute("type", "text/css");
            link.setAttribute("rel","stylesheet");
            link.setAttribute("href","//static.hdslb.com/phoenix/dist/css/comment.min.css");
            document.head.appendChild(link);
        }
    }
    function cover() {
        delete unsafeWindow.bbComment;
        new Function(GM_getResourceText("script"))();
        addCss(`.bb-comment .comment-header .header-page, .comment-bilibili-fold .comment-header .header-page {
        float: right;line-height: 36px;
        }
        .bb-comment .stick.assist, .comment-bilibili-fold .stick.assist, .bb-comment .stick.up, .comment-bilibili-fold .stick.up{
            border: 1px solid #ff81aa;
            min-width: 30px !important;;
            display: inline-block !important;;
            height: 18px !important;;
            line-height: 18px !important;;
            text-align: center !important;;
            font-size: 12px !important;;
            color: #ff81aa !important;;
            border-radius: 3px !important;;
            margin-right: 5px !important;;
            vertical-align: middle !important;;
            font-weight: 400 !important;;}
            .bb-comment .comment-list .list-item .user .level-link, .comment-bilibili-fold .comment-list .list-item .user .level-link {
            margin-left: unset !important;
            }`);
    }
    if (unsafeWindow.bbComment) cover();
    else {
        Object.defineProperty(unsafeWindow, "bbComment", {
            set: () => { cover() },
            get: () => undefined,
            configurable: true
        })
    }
})();