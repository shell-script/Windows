// ==UserScript==
// @name         Bilibili 翻页评论区
// @namespace    MotooriKashin
// @version      0.1.7
// @description  恢复原来的翻页评论区，同时修复评论楼层号。
// @author       MotooriKashin
// @match        *://*.bilibili.com/*
// @resource     script https://cdn.jsdelivr.net/gh/MotooriKashin/Bilibili-Old@c3c457edc3a3e08bf100a77ee0e8d5045f58c9fd/src/comment.min.js
// @resource     style https://static.hdslb.com/phoenix/dist/css/comment.min.css
// @run-at       document-start
// @grant        GM_getResourceText
// @license      MIT License
// ==/UserScript==

(function() {
    'use strict';

    function addCss(css, id) {
        if (!css) return;
        if (!document.head) return setTimeout(() => { this.addCss(css, id) });
        let style = document.createElement("style");
        if (id) {
            if (document.querySelector("#" + id)) return;
            style.setAttribute("id", id);
        }
        style.setAttribute("type", "text/css");
        style.appendChild(document.createTextNode(css));
        if (document.head) document.head.appendChild(style);
    }
    function cover() {
        delete unsafeWindow.bbComment;
        new Function(GM_getResourceText("script"))();
        addCss(GM_getResourceText("style") + ".bb-comment .comment-header .header-page, .comment-bilibili-fold .comment-header .header-page { float: right;line-height: 36px;}");
    }
    if (unsafeWindow.bbComment) cover();
    else {
        Object.defineProperty(unsafeWindow, "bbComment", {
            set: () => { cover() },
            get: () => undefined,
            configurable: true
        })
    }
})();