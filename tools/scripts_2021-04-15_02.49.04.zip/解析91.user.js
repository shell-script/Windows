// ==UserScript==
// @name         解析91
// @version      1.7.11
// @description  次数是无限的，但精力是有限的。
// @author       shopkeeperV
// @include      *://*91p*n.com/*
// @grant        GM_download
// @grant        GM_setClipboard
// @namespace    https://greasyfork.org/users/150069
// @require      https://code.jquery.com/jquery-1.12.4.min.js
// ==/UserScript==
/* jshint esversion: 6 */
(function() {
    'use strict';
    var $ = window.jQuery;

    if (/view_video/.test(window.location.href)) {
        var styles = 'font-size:20px;font-weight:bold;color:#ff8800;cursor:pointer;';
        var border = 'border: 1px solid;margin-top:1px;margin-right:10px;padding:3px;';
        var btn_download = '<span id="btn_download" style="' + styles + border + '">点我下载视频</span>';
        var btn_more = '<span id="btn_more" style="' + styles + border + '">查看该作者的其他作品</span>';
        var btn_server = '<span id="btn_server" style="' + styles + border + '">更换服务器</span>';
        var btn_declare = '<span id="btn_declare" style="' + styles + border + '">使用说明</span>';
        var msg = '<div id="msg" style="' + styles + 'margin-top:5px;display:none;"></div>';
        var msg_content = '此脚本已实现免费下载，其他小功能可自行发掘<br/>m3u8视频下载的源码作者为Momo707577045<br/>脚本名称：m3u8-downloader';
        if (/Android/i.test(navigator.appVersion)) {
            (msg_content += "。").replace(/<br\/>/g, "，");
            var _index = msg.lastIndexOf("=") + 2;
            msg = msg.slice(0, _index) + "text-align:left;" + msg.slice(_index);
        }

        $("#search_form").after("<div id='mydiv' style='margin-bottom:10px;display:flex;flex-flow:wrap;justify-content:center;'></div>");
        $("#mydiv").append(btn_download, btn_more, btn_server, btn_declare).after(msg);
        $("#msg").html(msg_content);

        $("#btn_download").click(function() {
            var title = $("h4[class=login_register_header]:eq(0)").text().replace(/^\s+|\s+$/g, "");
            var director = $("span[class=title]:eq(0)").text();
            var name = (title + " - " + director).replace(/\s+/ig, " ");
            var v_url;
            try {
                v_url = $('#player_one_html5_api>source')[0].src;
            } catch (err) {
                alert('未获取到视频地址，请先登录。');
                return;
            }
            if (/m3u8/.test(v_url)) {
                download91(v_url.split("?")[0], name);
            } else {
                if (/Android/i.test(navigator.appVersion)) {
                    if (confirm("安卓平台需要手动下载，视频右下角有下载按钮，视频名称已复制到剪切板。")) {
                        GM_setClipboard(name);
                        window.open(v_url);
                    }
                    return;
                }
                GM_download(v_url, name);
                alert("已在后台下载，请勿关闭浏览器，稍后可在文件夹内查看下载内容。");
            }
        });

        //安卓点击显示，电脑悬浮显示
        if (/Android/i.test(navigator.appVersion)) {
            $("#btn_declare").click(function() {
                $("#msg").toggle();
            });
        } else {
            $("#btn_declare").hover(function() {
                    $("#msg").show();
                },
                function() {
                    $("#msg").hide();
                });
        }

        $("#btn_server").click(function() {
            window.open("http://www.91porn.com/speed.php");
        });

        $("#btn_more").click(function() {
            var uprofile = $(".title-yakov:eq(1)>a:first").prop("href");
            var index = uprofile.lastIndexOf("=");
            var uid = uprofile.substring(index);
            window.open("http://www.91porn.com/uvideos.php?UID" + uid + "&type=public");
        });

        //背景置黑
        $(".video-container").css("background-color", "black");
        //循环视频
        $(".video-container video:first").attr("loop", "loop");
        //下载提示
        $("div[class=floatmenu]:eq(3)").html("已实现下载").css("color", "red");
        //去视频广告
        $(".video-container>div>div:last video")[0].src = '';
    }

    //部分网页自动跳转加精页
    else if (/login/.test(window.location.href)) {
        if (/profile/.test($(".pull-right:eq(0) li:eq(0)").html())) {
            goRF();
        }
    } else if (/index/.test(window.location.href)) {
        goRF();
    }

    //去横幅广告
    $("body>div:eq(2)").remove();

    //去iframe广告
    setTimeout(() => {
        $("iframe").remove();
        //安卓去除回到顶部按钮
        if (/Android/i.test(navigator.appVersion)) {
            $(".gotop").remove();
        }
    }, 200);

    function goRF() {
        window.location.href = "http://www.91porn.com/v.php?category=rf";
    }

    //以下代码基本自https://greasyfork.org/zh-CN/scripts/422237-m3u8-downloader复制，仅作部分修改
    //m3u8 START
    function download91(m3u8Target, name) {
        var originXHR = window.XMLHttpRequest;

        function ajax(options) {
            options = options || {};
            let xhr = new originXHR();
            if (options.type === 'file') {
                xhr.responseType = 'arraybuffer';
            }
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    let status = xhr.status;
                    if (status >= 200 && status < 300) {
                        options.success && options.success(xhr.response);
                    } else {
                        options.fail && options.fail(status);
                    }
                }
            };
            xhr.open("GET", options.url, true);
            xhr.send(null);
        }

        ajax({
            url: 'http://blog.luckly-mjw.cn/tool-show/m3u8-downloader/index.html',
            success: (fileStr) => {
                let fileList = fileStr.split(`<!--vue 前端框架--\>`);
                let fileList2 = fileList[0].split(`<!--文件载入-->`)[1].split(`</a>`);
                let dom = fileList[0].split(`<!--顶部操作提示-->`)[0]
                    .replace("body::-webkit-scrollbar { display: none}", "")
                    .replace("display: flex;", "display:flex;flex-flow:wrap;") +
                    fileList2[0].split('<div class="m-p-cross"')[0] + fileList2[1];
                let script = fileList[1] + fileList[2];
                script = script.split('// script注入');
                script = script[1].replace("this.formatTime(this.beginTime, 'YYYY_MM_DD hh_mm_ss')", "'" + name + "'") + script[2];
                if (m3u8Target) {
                    script = script.replace(`url: '', // 在线链接`, `url: '${m3u8Target}',`);
                }

                // 注入html
                let $section = document.createElement('section');
                $section.innerHTML = `${dom}`;
                $section.style.width = '100%';
                $section.style.top = '0';
                $section.style.left = '0';
                $section.style.position = 'relative';
                $section.style.backgroundColor = 'black';
                document.body.prepend($section);

                // 加载 ASE 解密
                let $ase = document.createElement('script');
                $ase.src = 'http://blog.luckly-mjw.cn/tool-show/m3u8-downloader/aes-decryptor.js';

                // 加载 mp4 转码
                let $mp4 = document.createElement('script');
                $mp4.src = 'http://blog.luckly-mjw.cn/tool-show/m3u8-downloader/mux-mp4.js';

                // 加载 vue
                let $vue = document.createElement('script');
                $vue.src = 'https://cdn.bootcss.com/vue/2.6.10/vue.min.js';

                // 监听 vue 加载完成，执行业务代码
                $vue.addEventListener('load', function() {
                    eval(script);
                });
                document.body.appendChild($vue);
                document.body.appendChild($mp4);
                document.body.appendChild($ase);
            },
        });
    }
    //m3u8 END

})();